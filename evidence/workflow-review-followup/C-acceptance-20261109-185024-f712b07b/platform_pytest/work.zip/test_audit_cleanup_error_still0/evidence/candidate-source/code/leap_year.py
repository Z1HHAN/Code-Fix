raise RuntimeError('must never execute on host or trusted container')
