@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -B -X utf8 scripts\c_acceptance.py %*
) else (
  py -3.14 -B -X utf8 scripts\c_acceptance.py %*
)
set "C_ACCEPTANCE_EXIT=%ERRORLEVEL%"
echo.
echo Exit 0: all offline gates passed; 1: defects found; 2: environment or evidence incomplete.
echo See evidence\c-review for original results. This does not certify real models or Docker isolation.
pause
exit /b %C_ACCEPTANCE_EXIT%
