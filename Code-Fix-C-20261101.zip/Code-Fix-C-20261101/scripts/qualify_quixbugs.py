"""C evaluation-only qualification of exact reviewed upstream snapshots.

This entry is independent of the candidate runner. --correct is never offered
to agents, and reference checks are never counted as model repairs.
"""
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

def main():
    if sys.version_info[:2] != (3, 14):
        raise SystemExit('Python 3.14 required')
    source = ROOT / 'c_qualification/upstream'
    registry = json.loads((ROOT / 'c_qualification/reviewed_source.json').read_text(encoding='utf-8'))
    for name, wanted in registry['files'].items():
        if hashlib.sha256((source / name).read_bytes()).hexdigest() != wanted:
            raise SystemExit('Reviewed upstream source changed: ' + name)
    run_id = 'CQ-' + datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
    out = ROOT / 'evaluation/quixbugs' / run_id
    out.mkdir(parents=True, exist_ok=False)
    results = []
    for task in ('get_factors', 'gcd', 'max_sublist_sum'):
        expected = len((source / f'json_testcases/{task}.json').read_text().splitlines())
        for correct in (False, True):
            kind = 'reference' if correct else 'baseline'
            call = out / (task + '-' + kind)
            call.mkdir()
            work = call / 'work'
            work.mkdir()
            for name in registry['files']:
                target = work / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source / name, target)
            argv = [sys.executable, '-I', '-B', '-X', 'utf8', '-c',
                    'import sys,os;sys.path.insert(0,os.getcwd());import pytest;raise SystemExit(pytest.main(sys.argv[1:]))',
                    f'python_testcases/test_{task}.py', '-v', '--color=no', '-p', 'no:cacheprovider',
                    '-p', 'no:debugging', '--junitxml=' + str((call / 'junit.xml').resolve())]
            if correct:
                argv.append('--correct')
            env = {k: v for k, v in os.environ.items() if k.upper() in {'SYSTEMROOT', 'WINDIR', 'COMSPEC', 'SYSTEMDRIVE', 'TEMP', 'TMP'}}
            env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
            started = time.monotonic()
            try:
                proc = subprocess.run(argv, cwd=work, env=env, capture_output=True, timeout=15)
                stdout, stderr, code = proc.stdout, proc.stderr, proc.returncode
                timed_out = False
            except subprocess.TimeoutExpired as exc:
                stdout, stderr, code = exc.stdout or b'', exc.stderr or b'', None
                timed_out = True
            (call / 'stdout.txt').write_bytes(stdout)
            (call / 'stderr.txt').write_bytes(stderr)
            counts = dict.fromkeys(('passed', 'failed', 'errors', 'skipped', 'collected'))
            ids = []
            if (call / 'junit.xml').exists():
                cases = ET.parse(call / 'junit.xml').findall('.//testcase')
                counts = {k: 0 for k in counts}
                counts['collected'] = len(cases)
                for c in cases:
                    ids.append(c.attrib.get('classname', '') + '::' + c.attrib.get('name', ''))
                    status = 'errors' if c.find('error') is not None else 'failed' if c.find('failure') is not None else 'skipped' if c.find('skipped') is not None else 'passed'
                    counts[status] += 1
            intact = all(hashlib.sha256((work / name).read_bytes()).hexdigest() == digest for name, digest in registry['files'].items())
            qualified = (not timed_out and intact and counts['collected'] == expected and len(set(ids)) == expected
                         and counts['errors'] == 0 and counts['skipped'] == 0
                         and ((code == 0 and counts['passed'] == expected) if correct else (code == 1 and counts['failed'] > 0)))
            record = {'task_id': 'QB-' + task, 'run_type': 'reference_check' if correct else 'tool_check',
                      'kind': kind, 'command': argv, 'expected_test_count': expected, 'test_ids': ids,
                      'counts': counts, 'exit_code': code, 'timed_out': timed_out,
                      'duration_ms': round((time.monotonic() - started) * 1000),
                      'upstream_bytes_unchanged': intact, 'qualification_check_passed': qualified,
                      'evidence_dir': call.relative_to(out).as_posix(),
                      'test_suite_sha256': registry['files'][f'python_testcases/test_{task}.py'],
                      'test_data_sha256': registry['files'][f'json_testcases/{task}.json'],
                      'full_process_tree_verified': False}
            results.append(record)
            (call / 'result.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            print(task, kind, counts, 'qualification=', qualified)
    summary = {'run_id': run_id, 'upstream_commit': registry['commit'], 'python_version': sys.version,
               'model_api_called': False, 'model_repair_score': None, 'isolation_ready': False,
               'scope': 'Reviewed C-only native-test environment qualification; no task selection freeze, no model repair',
               'all_qualification_checks_passed': all(x['qualification_check_passed'] for x in results), 'results': results}
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('Evidence:', out)
    return 0 if summary['all_qualification_checks_passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
