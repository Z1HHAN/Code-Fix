"""Verify frozen delivery bytes and current evidence bindings without executing tests."""
import argparse
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
from pathlib import Path
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'delivery-manifest.json'

def delivery_files():
    for base, dirs, files in os.walk(ROOT):
        path = Path(base)
        relative = path.relative_to(ROOT)
        if path == ROOT:
            dirs[:] = [d for d in dirs if d not in {'.venv', '.runtime', '.git', '.c_clean_check'}]
        if not relative.parts or relative.parts[0] != 'c_legacy':
            dirs[:] = [d for d in dirs if d not in {'__pycache__', '.pytest_cache'}]
        for name in files:
            p = path / name
            if p != MANIFEST:
                yield p

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def verify():
    entries = list(delivery_files())
    local_links = 0
    for p in entries:
        relative = p.relative_to(ROOT)
        if p.suffix != '.md' or relative.parts[0] == 'evaluation':
            continue
        for target in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8-sig')):
            if re.match(r'^[a-zA-Z][\w+.-]*:', target) or target.startswith('#'):
                continue
            target = unquote(target.split('#')[0])
            require((p.parent / target).exists(), f'Broken local link: {relative}: {target}')
            local_links += 1
    unit = json.loads((ROOT / 'evaluation/c_tests/20261101-232706-927f41e5/execution.json').read_text(encoding='utf-8'))
    require(unit['exit_code'] == 0, 'Control tests did not pass')
    for name, expected in unit['source_sha256'].items():
        require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, 'Source changed after tests: ' + name)
    for run in ('C-20261101-232721-f8b9a051', 'C-20261101-232837-df562cdf'):
        run_dir = ROOT / 'evaluation/c_runs' / run
        summary = json.loads((run_dir / 'summary.json').read_text(encoding='utf-8'))
        require(summary['all_control_checks_passed'] and summary['scenario_count'] == 12, 'Control acceptance failed')
        for name, expected in summary['runner_files_sha256'].items():
            require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, 'Runner changed after acceptance: ' + name)
        for record in summary['records']:
            result = record['result']
            for field in ('stdout_path', 'stderr_path', 'result_path'):
                require((run_dir / 'artifacts' / result[field]).is_file(), 'Missing call artifact')
            if result['junit_path']:
                require((run_dir / 'artifacts' / result['junit_path']).is_file(), 'Missing JUnit')
            else:
                require(bool(result['junit_missing_reason']), 'Missing reason for absent JUnit')
            stored = json.loads((run_dir / 'artifacts' / result['result_path']).read_text(encoding='utf-8'))
            require(stored == result, 'Summary and original call result disagree')
    upstream = json.loads((ROOT / 'c_qualification/reviewed_source.json').read_text(encoding='utf-8'))
    for name, digest in upstream['files'].items():
        require(hashlib.sha256((ROOT / 'c_qualification/upstream' / name).read_bytes()).hexdigest() == digest, 'Upstream source changed')
    old = ROOT / 'c_legacy/C_Day1_20261030'
    old_manifest = json.loads((old / 'handoff/文件校验清单.json').read_text(encoding='utf-8'))
    for name, digest in old_manifest['sha256'].items():
        require(hashlib.sha256((old / name).read_bytes()).hexdigest() == digest, 'Legacy byte mismatch: ' + name)
    return entries, local_links

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true', help='Reviewed release preparation only; overwrite checksum manifest')
    args = parser.parse_args()
    entries, links = verify()
    if args.freeze:
        data = {'created_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
                'scope': 'C local source and evidence release; not B integration or sandbox acceptance',
                'excluded': ['delivery-manifest.json', '.venv', '.runtime', '.git', 'nonhistorical caches'],
                'sha256': {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(entries)}}
        MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    data = json.loads(MANIFEST.read_text(encoding='utf-8'))
    for name, digest in data['sha256'].items():
        p = ROOT / name
        require(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == digest, 'Delivery mismatch: ' + name)
    print(f"PASS: {len(data['sha256'])} frozen file hashes; {links} documentation links; final evidence and source versions match.")

if __name__ == '__main__':
    main()
