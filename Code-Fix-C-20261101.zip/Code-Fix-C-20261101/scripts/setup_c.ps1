$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$archive = Join-Path $projectRoot 'runtime/python.3.14.6.nupkg'
$expected = '77271b5958f88608884998c27df6f8dd2fa59faf72614bc1e2ffd1d72a3336c3'
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLower() -ne $expected) {
    throw 'Python runtime archive checksum mismatch.'
}
$runtimeRoot = Join-Path $projectRoot '.runtime/python314'
$pythonExe = Join-Path $runtimeRoot 'tools/python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($archive, $runtimeRoot)
}
$signature = Get-AuthenticodeSignature -FilePath $pythonExe
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notlike '*Python Software Foundation*') {
    throw 'Python publisher signature could not be verified. Review the environment before running.'
}
& $pythonExe -c 'import sys; assert sys.version_info[:2] == (3,14)'
if ($LASTEXITCODE -ne 0) { throw 'Python 3.14 required.' }
$venvPython = Join-Path $projectRoot '.venv/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
    & $pythonExe -m venv (Join-Path $projectRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the local virtual environment.' }
}
& $venvPython -c 'import sys; assert sys.version_info[:2] == (3,14)'
if ($LASTEXITCODE -ne 0) { throw 'Existing .venv is not Python 3.14; keep it and use a new unpacked directory.' }
& $venvPython -m pip install --no-index --require-hashes --find-links=c_legacy/C_Day1_20261030/wheelhouse -r c_requirements.lock.txt
if ($LASTEXITCODE -ne 0) { throw 'Offline dependency installation failed.' }
Write-Host 'C environment ready: Python 3.14.6; no global installation or API configuration.'
