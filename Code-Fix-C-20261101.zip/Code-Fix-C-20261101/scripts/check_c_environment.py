"""Read-only C01 host inventory; never grants candidate execution permission."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone, timedelta

ROOT = Path(__file__).resolve().parents[1]

def capture(argv):
    try:
        p = subprocess.run(argv, capture_output=True, timeout=15, check=False)
        def decode(raw):
            return raw.decode('utf-16-le' if b'\0' in raw else 'utf-8', errors='replace')
        return {'command': argv, 'exit_code': p.returncode,
                'stdout': decode(p.stdout), 'stderr': decode(p.stderr)}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'command': argv, 'error_type': type(exc).__name__, 'message': str(exc)}

def main():
    report = {
        'checked_at': datetime.now(timezone(timedelta(hours=8))).isoformat(),
        'python_version': platform.python_version(),
        'python_executable': sys.executable,
        'pytest_version': importlib.metadata.version('pytest'),
        'platform': platform.platform(),
        'tools': {k: shutil.which(k) for k in ('docker', 'wsl', 'VBoxManage', 'vmrun')},
        'well_known_paths': {p: Path(p).is_file() for p in (
            'C:/Program Files/Docker/Docker/resources/bin/docker.exe',
            'C:/Program Files/Oracle/VirtualBox/VBoxManage.exe')},
        'host_secret_variables_present': {k: bool(os.environ.get(k)) for k in (
            'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GITHUB_TOKEN', 'AWS_SECRET_ACCESS_KEY')},
        'isolation_ready': False,
        'candidate_execution_enabled': False,
        'conclusion': 'No verified sandbox binding; reviewed fixed fixtures only. No claim that all virtual machines on this host have been discovered.',
        'isolation_checks': {k: 'not_verified' for k in (
            'sandbox_test_start', 'read_only_native_tests', 'no_model_keys_in_sandbox',
            'filesystem_boundary', 'network_limits', 'resource_limits', 'sandbox_process_tree_cleanup')},
    }
    if report['tools']['wsl']:
        report['wsl_inventory'] = capture([report['tools']['wsl'], '--list', '--quiet'])
    package = ROOT.parent / 'runtime-downloads/python.3.14.6.nupkg'
    if package.is_file():
        report['runtime_download'] = {
            'url': 'https://api.nuget.org/v3-flatcontainer/python/3.14.6/python.3.14.6.nupkg',
            'package_sha256': hashlib.sha256(package.read_bytes()).hexdigest(),
            'package_version': '3.14.6',
        }
    out = ROOT / 'evidence/c01/environment.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'python': report['python_version'], 'pytest': report['pytest_version'],
                      'isolation_ready': False, 'report': str(out)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
