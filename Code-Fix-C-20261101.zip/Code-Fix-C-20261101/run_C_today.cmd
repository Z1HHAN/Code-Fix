@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run setup_C_today.cmd first.
  pause
  exit /b 1
)
set "PYTEST_DISABLE_PLUGIN_AUTOLOAD=1"
set "PYTHONDONTWRITEBYTECODE=1"
".venv\Scripts\python.exe" -X utf8 scripts\run_c_acceptance.py
set "RESULT=%ERRORLEVEL%"
echo Results are in evaluation\c_runs. Expected buggy-code failures are control checks.
pause
exit /b %RESULT%
