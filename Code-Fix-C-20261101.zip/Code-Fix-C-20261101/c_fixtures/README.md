# C 已审阅的固定控制样例

本目录仅用于验证确定性 runner，不属于模型修复成绩，也不是 QuixBugs 目标测试。所有样例均无模型调用、无网络操作。`profiles.json` 冻结文件哈希、测试 ID 与源文件路径；runner 只能执行与冻结快照逐字节一致的副本。

| 样例 | 用途 | 预期 |
| --- | --- | --- |
| leap_bad | 原始闰年缺陷基线 | 3 通过、1 失败，1900 年断言失败 |
| leap_good | 已知正确参考 | 同一套四条测试全部通过，仅 reference_check |
| leap_all_skipped | 已知代码主动抛 SkipTest | 全部跳过，不得通过 |
| output_timeout | stdout/stderr 刷新后等待 30 秒 | 2 秒受控时限后 timeout，保留部分日志 |
| zero_tests | 测试文件没有测试函数 | 零用例，不得通过 |
| incomplete_tests | 实际只含 1 条，登记预期 4 条 | 缺测，不得通过 |
| collection_dependency_error | 导入刻意不存在的依赖 | 环境/收集错误，不得通过 |
| collection_syntax_error | 已知源文件语法错误 | syntax_error，不得误当测试断言失败 |
| code_runtime_error | 已知函数抛 ValueError | code_runtime_error，不得通过 |

闰年四条断言保留 main/day1-kit 的既有含义；这里使用 `leap_app` 导入避免标准库 `code` 同名问题。bad/good 测试文件字节一致。故障注入样例不用于推断模型能力。

使用 `scripts/run_c_acceptance.py` 产生真实结果，使用 `python -m pytest c_tests` 验证控制边界。参考正确代码只在 C 的评测目录中使用，不应导入 Agent 工作副本。
