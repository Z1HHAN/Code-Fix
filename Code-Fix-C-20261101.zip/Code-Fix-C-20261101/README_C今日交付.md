# C 11月1日交付

本包基于用户提供的 main 归档，完成 C 侧最小执行器、真实控制检查、环境实况登记和旧包派生归档。Python 统一为 **3.14.6**。不修改 B 分支，不调用模型，不代填 B/C 签收或隔离通过。

## 已完成

| 任务 | 本轮结果 | 证据 |
| --- | --- | --- |
| C01 环境实况 | 已检查；无已验证的容器/VM绑定，WSL未安装，候选执行关闭 | [环境JSON](evidence/c01/environment.json)、[解释器签名](evidence/c01/runtime-signature.json) |
| C02 最小runner | 固定测试方案、JUnit与用例身份校验、版本核对、独立调用产物、超时日志与回收 | [源代码](c_runner/runner.py)、[接口说明](docs/c/C02-接口与运行说明.md) |
| C03 C侧控制回归 | 22个控制测试通过；12个真实场景符合预期 | [测试日志](evaluation/c_tests/20261101-232706-927f41e5/stdout.txt)、[场景结果](evaluation/c_runs/C-20261101-232721-f8b9a051/report.md) |
| 干净目录复跑 | 从新目录离线安装Python与依赖，12场景再次通过 | [复跑记录](evidence/clean_reproduction.json)、[复跑场景](evaluation/c_runs/C-20261101-232837-df562cdf/report.md) |
| C04 旧包整理 | 58项哈希、69个链接通过；规范非历史换行，历史证据字节保留 | [旧包复核](docs/c/C04-旧包复核.md) |
| QuixBugs资格补充 | 固定版本三题均复现坏代码失败，参考实现全部通过原生测试 | [资格记录](docs/c/QuixBugs资格记录.md) |

“控制检查通过”包含故意制造的失败：坏代码应为3通过1失败，正确参考应为4通过；超时应返回timeout；全跳过、零测试、缺测、错误和陈旧版本不得误判通过。它不表示12个目标程序全部正确。

## 在这台或另一台 Windows 电脑运行

1. 完整解压本包到有写入权限的新目录。
2. 双击 `setup_C_today.cmd`。它检查随包Python归档哈希及解释器发布者签名，在项目内创建运行时和虚拟环境，并按哈希锁定文件离线安装依赖；不修改系统Python、不要求密钥。
3. 双击 `run_C_today.cmd`。结果写入新建的 `evaluation/c_runs/C-时间-随机值/`，旧记录不会覆盖。

也可以在项目目录运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/setup_c.ps1
.\.venv\Scripts\python.exe -X utf8 scripts/run_c_acceptance.py
.\.venv\Scripts\python.exe -X utf8 scripts/verify_c_delivery.py
```

校验脚本核对出厂文件；复跑新增的证据允许额外存在，不会改写出厂清单。若修改源代码，要新建交付版本并重跑测试，不把旧通过记录沿用到新实现。

## 需要保留的边界

- 本runner只执行登记哈希完全一致的已审fixture。它不是安全沙箱；`model_candidate`及其他执行模式直接blocked，设置环境变量也不能开启。
- 22项控制测试和12场景为C生产端自测；B消费、双方签收仍未进行，接口仍为 `0.2-20261101-draft`。
- 超时真实验证了带输出的单个受控父进程，记录了taskkill尝试、父进程回收与管道收尾。复杂进程树、网络和文件隔离未验证。
- QuixBugs参考实现仅放在C评测区，绝不能将整个 `c_qualification/` 或参考结果复制到模型工作区。资格检查不是模型成绩，也不是正式名单冻结。
- 旧包的历史runs保持原样；新的真实Python3.14记录由本执行器单列。Git集成/干净克隆换行复验待实际集成后执行。
- 没有创建新的Git提交或推送远程；归档基线声明为 `bb6229a3415cf62bf2318277ea0227a2d0ad7b26`，本次实现用源码SHA256绑定，不能把基线commit当成本次实现commit。

详细登记见 [今日台账](docs/daily/2026-11-01.md)。Python归档来自 [CPython的NuGet包](https://www.nuget.org/packages/python/3.14.6)，具体下载哈希及本机签名验证结果见C01证据，不沿用旧包未知来源的声明。
