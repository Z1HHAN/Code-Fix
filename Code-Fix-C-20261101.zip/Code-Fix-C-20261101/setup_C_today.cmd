@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts\setup_c.ps1
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
