# C 旧交付包的派生归档

本目录保存用户提供的 `C_Day1_Python3.14_v0.1` 的派生整理版本。目标版本为 Python 3.14，原始历史运行记录版本为 3.14.6；本归档不是新的模型修复运行，也不是通用 runner 的验收。

- [旧包入口](C_Day1_20261030/README.md)
- [来源文件逐项 SHA256](source_snapshot.json)
- [本轮静态及干净文件副本核查](archive_check.json)
- [可重跑核查脚本](audit_archive.py)
- [C04 复核记录](../docs/c/C04-旧包复核.md)

旧包内 `runs/` 的30个文件及绑定的4个来源代码、测试、参考文件逐字节保留。非历史文本规范为 LF，Windows `.cmd` 规范为 CRLF。修改 `verify_delivery.py` 的冻结写入使用明确 LF，避免在 Windows 上重建索引与清单时再次引入平台换行漂移。索引与校验清单在修改完成后重建。

从本项目根目录可用 Python 执行以下只读检查；它不启动旧测试 runner：

```text
python c_legacy/audit_archive.py --clean-copy
```

`--clean-copy` 在本目录的临时独立副本中复验文件集、全部哈希和链接，结束后清理该临时目录。它不代表 Git 干净克隆检查。`--write-report` 可额外更新本目录的机器可读报告。

Git 集成时应让已冻结且受字节清单覆盖的 `C_Day1_20261030/**` 使用 `-text`，避免 checkout 再次改变冻结字节；外层新源代码可以采用仓库统一 LF。历史证据、原始来源哈希和新执行器证据应分别保留，不重新解释为同一轮运行。
