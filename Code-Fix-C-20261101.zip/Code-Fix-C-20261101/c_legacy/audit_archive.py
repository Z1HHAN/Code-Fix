"""Verify the derived legacy package without executing its historical runner.

Only reads inputs unless --write-report is supplied. All historical run files
must match the saved source SHA256 snapshot. The checksum excludes only itself.
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import unquote

BASE = Path(__file__).resolve().parent
PACKAGE = BASE / 'C_Day1_20261030'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    provenance = json.loads((BASE / 'source_snapshot.json').read_text(encoding='utf-8'))
    manifest = json.loads((PACKAGE / 'handoff/文件校验清单.json').read_text(encoding='utf-8'))
    current = {p.relative_to(PACKAGE).as_posix(): sha(p)
               for p in PACKAGE.rglob('*') if p.is_file()}
    expected = manifest['sha256']
    assert set(current) == set(expected) | {'handoff/文件校验清单.json'}, 'Unexpected/missing file set'
    assert all(current[n] == h for n, h in expected.items()), 'Checksum mismatch'
    historical = {n: h for n, h in provenance['original_sha256'].items() if n.startswith('runs/')}
    assert all(current[n] == h for n, h in historical.items()), 'Historical evidence changed'
    source_files = {n: h for n, h in provenance['original_sha256'].items()
                    if n.startswith(('code/', 'tests/', 'reference/'))}
    assert all(current[n] == h for n, h in source_files.items()), 'Historical source/test changed'
    line_endings = {'LF': 0, 'CRLF': 0, 'no_newline': 0, 'historical_exempt': 0}
    link_count = 0
    for p in PACKAGE.rglob('*'):
        if not p.is_file():
            continue
        rel = p.relative_to(PACKAGE)
        if rel.parts[0] == 'runs':
            line_endings['historical_exempt'] += 1
            continue
        if p.suffix.lower() in {'.py', '.md', '.html', '.json', '.txt', '.cmd'}:
            raw = p.read_bytes()
            if p.suffix.lower() == '.cmd':
                assert raw.count(b'\n') == raw.count(b'\r\n'), f'CMD must use CRLF: {rel}'
                line_endings['CRLF'] += 1
            elif b'\n' not in raw:
                assert b'\r' not in raw, f'Unexpected CR: {rel}'
                line_endings['no_newline'] += 1
            else:
                assert b'\r' not in raw, f'Text must use LF: {rel}'
                line_endings['LF'] += 1
        if p.suffix.lower() not in {'.md', '.html'}:
            continue
        text = p.read_text(encoding='utf-8')
        links = re.findall(r'\]\(([^)]+)\)', text) if p.suffix.lower() == '.md' else re.findall(r'href=["\x27]([^"\x27]+)', text)
        for target in links:
            if '://' in target or target.startswith('#'):
                continue
            dest = (p.parent / unquote(target.split('#')[0])).resolve()
            assert dest.is_relative_to(PACKAGE.resolve()) and dest.is_file(), f'Broken/escaping link {rel}: {target}'
            link_count += 1
    changed = [n for n, old_hash in provenance['original_sha256'].items() if current[n] != old_hash]
    report = {
        'check_type': 'legacy_archive_static_check',
        'checksum_entries': len(expected),
        'local_links_checked': link_count,
        'historical_files_byte_preserved': len(historical),
        'source_test_reference_files_byte_preserved': len(source_files),
        'line_endings': line_endings,
        'derived_changed_files': changed,
        'python_314_rerun_performed_by_this_check': False,
        'git_clean_clone_verified': False,
        'model_api_called': False,
        'status': 'passed',
    }
    if '--clean-copy' in sys.argv:
        with tempfile.TemporaryDirectory(prefix='c04-check-', dir=BASE) as folder:
            clean_root = Path(folder).resolve()
            assert clean_root.is_relative_to(BASE.resolve())
            shutil.copytree(PACKAGE, clean_root / PACKAGE.name)
            shutil.copy2(BASE / 'source_snapshot.json', clean_root / 'source_snapshot.json')
            shutil.copy2(Path(__file__), clean_root / 'audit_archive.py')
            checked = subprocess.run([sys.executable, str(clean_root / 'audit_archive.py')],
                                     capture_output=True, text=True, encoding='utf-8', check=True)
            clean_report = json.loads(checked.stdout)
            assert clean_report['status'] == 'passed'
            assert clean_report['checksum_entries'] == report['checksum_entries']
            assert clean_report['local_links_checked'] == report['local_links_checked']
            report['clean_filesystem_copy_verified'] = True
            report['clean_copy_method'] = 'New independent filesystem copy; no Git checkout/clone claim'
    if '--write-report' in sys.argv:
        (BASE / 'archive_check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
